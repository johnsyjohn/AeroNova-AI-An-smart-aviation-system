import sys
import os

# Add current directory to sys.path
sys.path.append(os.getcwd())

from app import app, db
from models.models import User

def check_users():
    with app.app_context():
        users = User.query.all()
        print("--- USER LIST ---")
        for u in users:
            print(f"ID: {u.id} | User: {u.username} | Role: {u.role} | Email: {u.email}")
        print("-----------------")

if __name__ == "__main__":
    check_users()

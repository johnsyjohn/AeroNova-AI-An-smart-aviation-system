import re

class AeroChat:
    def __init__(self):
        self.rules = {
            r'book|ticket|reserve': "You can search for flights on our homepage and click 'Book Now' to start the reservation process.",
            r'cancel|refund': "To cancel a ticket, go to your Profile Dashboard, find your booking, and click 'Cancel'. Refunds are processed within 5-7 business days.",
            r'baggage|luggage|weight': "AeroNova Airways allows 15kg of check-in baggage and 7kg of cabin baggage on economy flights.",
            r'status|check': "You can check your flight status in the 'My Bookings' section of your profile.",
            r'hello|hi|hey': "Hello! Welcome to AeroNova Airways support. How can I help you today?",
            r'bye|thanks|thank you': "You're welcome! Thank you for choosing AeroNova Airways. Have a great day!"
        }
        self.default_response = "I'm sorry, I didn't quite catch that. Could you please rephrase? You can ask about booking, cancellation, baggage, or flight status."

    def get_response(self, user_query):
        user_query = user_query.lower()
        for pattern, response in self.rules.items():
            if re.search(pattern, user_query):
                return response
        return self.default_response

# Basic test
if __name__ == "__main__":
    chat = AeroChat()
    print(chat.get_response("How to cancel my ticket?"))
    print(chat.get_response("What is the baggage policy?"))

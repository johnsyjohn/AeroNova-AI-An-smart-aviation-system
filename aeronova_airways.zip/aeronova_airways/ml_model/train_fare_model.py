import pandas as pd
import numpy as np
import pickle
import os
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

# Seed for reproducibility
np.random.seed(42)

def generate_sample_data():
    sources = ['Mumbai', 'Delhi', 'Bangalore', 'Hyderabad', 'Chennai']
    destinations = ['Delhi', 'Mumbai', 'Kolkata', 'Bangalore', 'Chennai']
    
    data = []
    for _ in range(1000):
        src = np.random.choice(sources)
        dest = np.random.choice([d for d in destinations if d != src])
        hour = np.random.randint(0, 24)
        seats = np.random.randint(0, 200)
        # Base price formula: base + distance factor + peak hour factor - seat availability factor
        price = 2000 + np.random.randint(500, 5000) + (100 if 8 <= hour <= 20 else 0) - (seats * 2)
        data.append([src, dest, hour, seats, price])
        
    return pd.DataFrame(data, columns=['source', 'destination', 'departure_hour', 'seat_availability', 'price'])

def train_model():
    df = generate_sample_data()
    
    # Preprocessing
    le_source = LabelEncoder()
    le_dest = LabelEncoder()
    
    df['source'] = le_source.fit_transform(df['source'])
    df['destination'] = le_dest.fit_transform(df['destination'])
    
    X = df.drop('price', axis=1)
    y = df['price']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    # Save model and encoders
    os.makedirs('ml_model', exist_ok=True)
    with open('ml_model/fare_model.pkl', 'wb') as f:
        pickle.dump(model, f)
    with open('ml_model/le_source.pkl', 'wb') as f:
        pickle.dump(le_source, f)
    with open('ml_model/le_dest.pkl', 'wb') as f:
        pickle.dump(le_dest, f)
        
    print("Model trained and saved to ml_model/")

if __name__ == "__main__":
    train_model()

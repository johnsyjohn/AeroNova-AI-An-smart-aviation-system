import pandas as pd
import numpy as np

def recommend_flights(user_preferences, available_flights):
    """
    Recommend flights based on user budget, preferred time, and direct vs connecting.
    user_preferences: dict with keys 'budget', 'preferred_time', 'direct'
    available_flights: list of flight objects or dictionaries
    """
    scored_flights = []
    
    for flight in available_flights:
        score = 0
        
        # Budget scoring (closer to budget is better, but below is best)
        if flight['price'] <= user_preferences['budget']:
            score += 10
        elif flight['price'] <= user_preferences['budget'] * 1.2:
            score += 5
            
        # Time preference (morning, afternoon, night)
        departure_hour = flight['departure_time'].hour
        pref_time = user_preferences.get('preferred_time', 'any')
        
        if pref_time == 'morning' and 5 <= departure_hour < 12:
            score += 10
        elif pref_time == 'afternoon' and 12 <= departure_hour < 18:
            score += 10
        elif pref_time == 'night' and (18 <= departure_hour or departure_hour < 5):
            score += 10
        elif pref_time == 'any':
            score += 5
            
        # Direct vs Connecting (for now all are direct in our mock)
        if user_preferences.get('direct', True):
            score += 5
            
        scored_flights.append((flight, score))
        
    # Sort by score descending
    scored_flights.sort(key=lambda x: x[1], reverse=True)
    
    # Return top 3 recommendations
    return [f[0] for f in scored_flights[:3]]

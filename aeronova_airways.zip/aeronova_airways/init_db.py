from app import app, db
from models.models import User, Flight
from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta

def init_test_data():
    with app.app_context():
        db.create_all()
        
        # Create/Update Admin
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            admin = User(username='admin', email='admin@aeronova.com', 
                         password_hash=generate_password_hash('admin123'),
                         role='admin')
            db.session.add(admin)
        else:
            admin.role = 'admin' # Ensure role is correct if user already exists
            admin.password_hash = generate_password_hash('admin123')
        
        # Create/Update Sample User
        demo = User.query.filter_by(username='demo').first()
        if not demo:
            demo = User(username='demo', email='demo@example.com', 
                        password_hash=generate_password_hash('demo123'),
                        role='user')
            db.session.add(demo)

        # Diverse Flights
        if Flight.query.count() < 10:
            flights = [
                # Mumbai -> Delhi
                Flight(flight_number='AN501', source='Mumbai', destination='Delhi', 
                       departure_time=datetime.now() + timedelta(days=1, hours=9),
                       arrival_time=datetime.now() + timedelta(days=1, hours=11),
                       base_price=5200.0, available_seats=180, total_seats=180),
                Flight(flight_number='AN505', source='Mumbai', destination='Delhi', 
                       departure_time=datetime.now() + timedelta(days=1, hours=14),
                       arrival_time=datetime.now() + timedelta(days=1, hours=16),
                       base_price=5800.0, available_seats=150, total_seats=180),
                Flight(flight_number='AN506', source='Mumbai', destination='Delhi', 
                       departure_time=datetime.now() + timedelta(days=1, hours=20),
                       arrival_time=datetime.now() + timedelta(days=1, hours=22),
                       base_price=4500.0, available_seats=200, total_seats=200),
                
                # Delhi -> Mumbai
                Flight(flight_number='AN502', source='Delhi', destination='Mumbai', 
                       departure_time=datetime.now() + timedelta(days=1, hours=18),
                       arrival_time=datetime.now() + timedelta(days=1, hours=20),
                       base_price=4800.0, available_seats=150, total_seats=180),
                Flight(flight_number='AN507', source='Delhi', destination='Mumbai', 
                       departure_time=datetime.now() + timedelta(days=1, hours=6),
                       arrival_time=datetime.now() + timedelta(days=1, hours=8),
                       base_price=4200.0, available_seats=180, total_seats=180),
                Flight(flight_number='AN508', source='Delhi', destination='Mumbai', 
                       departure_time=datetime.now() + timedelta(days=1, hours=22),
                       arrival_time=datetime.now() + timedelta(days=1, hours=0),
                       base_price=5500.0, available_seats=100, total_seats=180),

                # Bangalore -> Hyderabad
                Flight(flight_number='AN503', source='Bangalore', destination='Hyderabad', 
                       departure_time=datetime.now() + timedelta(days=2, hours=10),
                       arrival_time=datetime.now() + timedelta(days=2, hours=11),
                       base_price=3200.0, available_seats=120, total_seats=150),
                Flight(flight_number='AN509', source='Bangalore', destination='Hyderabad', 
                       departure_time=datetime.now() + timedelta(days=2, hours=15),
                       arrival_time=datetime.now() + timedelta(days=2, hours=16),
                       base_price=3500.0, available_seats=140, total_seats=150),
                
                # Chennai -> Kolkata
                Flight(flight_number='AN504', source='Chennai', destination='Kolkata', 
                       departure_time=datetime.now() + timedelta(days=3, hours=7),
                       arrival_time=datetime.now() + timedelta(days=3, hours=9, minutes=30),
                       base_price=6500.0, available_seats=20, total_seats=180),
                Flight(flight_number='AN510', source='Chennai', destination='Kolkata', 
                       departure_time=datetime.now() + timedelta(days=3, hours=13),
                       arrival_time=datetime.now() + timedelta(days=3, hours=15, minutes=30),
                       base_price=6800.0, available_seats=150, total_seats=180),
                
                # Mumbai -> Goa
                Flight(flight_number='AN601', source='Mumbai', destination='Goa', 
                       departure_time=datetime.now() + timedelta(days=1, hours=10),
                       arrival_time=datetime.now() + timedelta(days=1, hours=11, minutes=15),
                       base_price=3500.0, available_seats=180, total_seats=180),
                Flight(flight_number='AN602', source='Mumbai', destination='Goa', 
                       departure_time=datetime.now() + timedelta(days=1, hours=17),
                       arrival_time=datetime.now() + timedelta(days=1, hours=18, minutes=15),
                       base_price=3800.0, available_seats=150, total_seats=180),
                
                # Delhi -> Goa
                Flight(flight_number='AN603', source='Delhi', destination='Goa', 
                       departure_time=datetime.now() + timedelta(days=2, hours=8),
                       arrival_time=datetime.now() + timedelta(days=2, hours=10, minutes=45),
                       base_price=6200.0, available_seats=180, total_seats=180)
            ]
            # Clear existing flights to avoid duplication if running multiple times
            Flight.query.delete()
            db.session.bulk_save_objects(flights)
            
        db.session.commit()
        print("Database initialized with Admin and sample flights.")

if __name__ == "__main__":
    init_test_data()

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import pickle
import os
import pandas as pd

from models.models import db, User, Flight, Booking
from ml_model.recommender import recommend_flights
from ml_model.trend_predictor import get_trend_predictions
from chatbot.bot import AeroChat
from reportlab.pdfgen import canvas
from io import BytesIO

app = Flask(__name__)
app.config['SECRET_KEY'] = 'aeronova_secret_key_123'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///aeronova.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

chat_bot = AeroChat()
TAX_RATE = 0.12

def get_predicted_price(flight, src, dest):
    pred_price = flight.base_price
    if fare_model and src in le_source.classes_ and dest in le_dest.classes_:
        try:
            input_df = pd.DataFrame([[le_source.transform([src])[0], 
                                     le_dest.transform([dest])[0], 
                                     flight.departure_time.hour, 
                                     flight.available_seats]], 
                                   columns=['source', 'destination', 'departure_hour', 'seat_availability'])
            pred_price = fare_model.predict(input_df)[0]
        except:
            pass
    return round(pred_price, 2)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Load ML components
try:
    with open('ml_model/fare_model.pkl', 'rb') as f:
        fare_model = pickle.load(f)
    with open('ml_model/le_source.pkl', 'rb') as f:
        le_source = pickle.load(f)
    with open('ml_model/le_dest.pkl', 'rb') as f:
        le_dest = pickle.load(f)
except FileNotFoundError:
    print("Warning: ML model files not found. Prediction may fail.")
    fare_model = None

# Initialize Database with Sample Data
# Database initialization is handled by init_db.py

# --- Routes ---

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists')
            return redirect(url_for('register'))
        if User.query.filter_by(email=email).first():
            flash('Email already registered')
            return redirect(url_for('register'))
            
        new_user = User(username=username, email=email, 
                        password_hash=generate_password_hash(password))
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            if user.role == 'admin':
                return redirect(url_for('admin_panel'))
            return redirect(url_for('index'))
        flash('Invalid login credentials')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/search', methods=['GET'])
def search_flights():
    source = request.args.get('source')
    destination = request.args.get('destination')
    date_str = request.args.get('date')
    
    query = Flight.query.filter(Flight.source.ilike(f'%{source}%'), 
                                Flight.destination.ilike(f'%{destination}%'))
    
    flights = query.all()
    
    # AI Fare Prediction for results
    results = []
    for f in flights:
        fare = get_predicted_price(f, source, destination)
        tax = round(fare * TAX_RATE, 2)
        total = round(fare + tax, 2)
        
        # Get 7-day trend
        trend = get_trend_predictions(f.id, source, destination, f.departure_time.hour, total)
        
        suggestion = "Price stable"
        suggestion_type = "neutral"
        
        if trend:
            min_price = trend['min']
            min_index = trend['prices'].index(min_price)
            
            if min_index == 0:
                suggestion = "Book Now"
                suggestion_type = "urgent"
            elif min_index > 0:
                suggestion = f"Wait for {min_index} days"
                suggestion_type = "save"
            
            if trend['prices'][-1] > total * 1.1:
                suggestion += " • Likely to increase"

        results.append({
            'id': f.id,
            'flight_number': f.flight_number,
            'departure': f.departure_time.strftime('%H:%M'),
            'arrival': f.arrival_time.strftime('%H:%M'),
            'price': total,
            'fare': fare,
            'tax': tax,
            'actual_price': f.base_price,
            'seats': f.available_seats,
            'trend': trend,
            'suggestion': suggestion,
            'suggestion_type': suggestion_type
        })
        
    return render_template('results.html', flights=results, source=source, dest=destination)

@app.route('/notify_fare', methods=['POST'])
@login_required
def notify_fare():
    data = request.json
    # In a real app, save this to a Watchlist database table
    # For now, we'll just mock a success response
    return jsonify({'status': 'success', 'message': f"We'll notify you if fares for {data.get('flight_number')} drop!"})

@app.route('/book/<int:flight_id>', methods=['GET', 'POST'])
@login_required
def book_flight(flight_id):
    flight = Flight.query.get_or_404(flight_id)
    source = request.args.get('source', flight.source)
    destination = request.args.get('destination', flight.destination)
    
    fare = get_predicted_price(flight, source, destination)
    tax = round(fare * TAX_RATE, 2)
    total = round(fare + tax, 2)
    
    if request.method == 'POST':
        session['booking_data'] = {
            'flight_id': flight.id,
            'seat': request.form.get('seat', '1A'),
            'passenger_name': request.form.get('passenger_name'),
            'passenger_age': int(request.form.get('passenger_age', 0)),
            'passenger_mobile': request.form.get('passenger_mobile'),
            'source': source,
            'destination': destination
        }
        return redirect(url_for('payment'))
    return render_template('booking.html', flight=flight, fare=fare, tax=tax, total=total)

@app.route('/payment', methods=['GET', 'POST'])
@login_required
def payment():
    booking_data = session.get('booking_data')
    if not booking_data:
        flash('No booking in progress.')
        return redirect(url_for('index'))
    
    flight = Flight.query.get_or_404(booking_data['flight_id'])
    fare = get_predicted_price(flight, booking_data['source'], booking_data['destination'])
    tax = round(fare * TAX_RATE, 2)
    total = round(fare + tax, 2)

    if request.method == 'POST':
        pay_method = request.form.get('payment_method')
        
        booking = Booking(
            user_id=current_user.id, 
            flight_id=flight.id, 
            total_amount=total, 
            seat_number=booking_data['seat'],
            passenger_name=booking_data['passenger_name'],
            passenger_age=booking_data['passenger_age'],
            passenger_mobile=booking_data['passenger_mobile'],
            payment_method=pay_method
        )
        flight.available_seats -= 1
        db.session.add(booking)
        db.session.commit()
        
        session.pop('booking_data', None)
        flash(f'Booking successful for flight {flight.flight_number}!')
        return redirect(url_for('dashboard'))

    return render_template('payment.html', flight=flight, fare=fare, tax=tax, total=total, booking_data=booking_data)

@app.route('/cancel/<int:booking_id>', methods=['POST'])
@login_required
def cancel_booking(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    if booking.user_id != current_user.id:
        return "Unauthorized", 403
    
    booking.status = 'cancelled'
    booking.flight.available_seats += 1
    db.session.commit()
    flash('Booking cancelled successfully.')
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
@login_required
def dashboard():
    bookings = Booking.query.filter_by(user_id=current_user.id).all()
    # Recommendations based on past bookings if any
    recommendations = []
    if bookings:
        last_dest = bookings[-1].flight.destination
        rec_flights = Flight.query.filter(Flight.destination == last_dest, Flight.available_seats > 0).limit(3).all()
        # Mocking recommendation scores
        recommendations = recommend_flights({'budget': 5000, 'preferred_time': 'morning'}, 
                                            [{'id': f.id, 'price': f.base_price, 'departure_time': f.departure_time, 'flight_number': f.flight_number} for f in rec_flights])
    
    return render_template('dashboard.html', bookings=bookings, recommendations=recommendations)

@app.route('/admin')
@login_required
def admin_panel():
    if current_user.role != 'admin':
        return f"Access Denied: You are logged in as '{current_user.username}' with role '{current_user.role}'. Only 'admin' users can access this page. Please logout and login as the administrator.", 403
    flights = Flight.query.all()
    bookings = Booking.query.all()
    users = User.query.all()
    return render_template('admin.html', flights=flights, bookings=bookings, users=users)

@app.route('/admin/delete_user/<int:user_id>', methods=['POST'])
@login_required
def delete_user(user_id):
    if current_user.role != 'admin': return f"Access Denied: Admin role required (Current: {current_user.role})", 403
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("You cannot delete yourself!")
        return redirect(url_for('admin_panel'))
    db.session.delete(user)
    db.session.commit()
    flash(f"User {user.username} deleted.")
    return redirect(url_for('admin_panel'))

@app.route('/admin/delete_booking/<int:booking_id>', methods=['POST'])
@login_required
def delete_booking(booking_id):
    if current_user.role != 'admin': return f"Access Denied: Admin role required (Current: {current_user.role})", 403
    booking = Booking.query.get_or_404(booking_id)
    db.session.delete(booking)
    db.session.commit()
    flash("Booking record deleted.")
    return redirect(url_for('admin_panel'))

@app.route('/admin/delete_flight/<int:flight_id>', methods=['POST'])
@login_required
def delete_flight(flight_id):
    if current_user.role != 'admin': return f"Access Denied: Admin role required (Current: {current_user.role})", 403
    flight = Flight.query.get_or_404(flight_id)
    db.session.delete(flight)
    db.session.commit()
    flash(f"Flight {flight.flight_number} removed.")
    return redirect(url_for('admin_panel'))

@app.route('/admin/add_flight', methods=['POST'])
@login_required
def add_flight():
    if current_user.role != 'admin': return f"Access Denied: Admin role required (Current: {current_user.role})", 403
    
    new_flight = Flight(
        flight_number=request.form['flight_number'],
        source=request.form['source'],
        destination=request.form['destination'],
        departure_time=datetime.strptime(request.form['departure'], '%Y-%m-%dT%H:%M'),
        arrival_time=datetime.strptime(request.form['arrival'], '%Y-%m-%dT%H:%M'),
        base_price=float(request.form['price']),
        available_seats=int(request.form['seats']),
        total_seats=int(request.form['seats'])
    )
    db.session.add(new_flight)
    db.session.commit()
    flash('Flight added successfully!')
    return redirect(url_for('admin_panel'))

@app.route('/admin/edit_price/<int:flight_id>', methods=['POST'])
@login_required
def edit_price(flight_id):
    if current_user.role != 'admin': return f"Access Denied: Admin role required (Current: {current_user.role})", 403
    flight = Flight.query.get_or_404(flight_id)
    flight.base_price = float(request.form['new_price'])
    db.session.commit()
    flash(f'Price updated for {flight.flight_number}')
    return redirect(url_for('admin_panel'))

@app.route('/chat', methods=['POST'])
def chat():
    user_msg = request.json.get('message')
    response = chat_bot.get_response(user_msg)
    return jsonify({'response': response})

@app.route('/download_ticket/<int:booking_id>')
@login_required
def download_ticket(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    if booking.user_id != current_user.id:
        return "Unauthorized", 403
    
    buffer = BytesIO()
    p = canvas.Canvas(buffer)
    
    # Draw Ticket
    p.setFont("Helvetica-Bold", 16)
    p.drawString(100, 750, "AeroNova Airways - E-Ticket")
    p.setFont("Helvetica", 12)
    p.line(100, 740, 500, 740)
    
    p.drawString(100, 710, f"Passenger: {booking.passenger_name}")
    p.drawString(100, 690, f"Age: {booking.passenger_age} | Mobile: {booking.passenger_mobile}")
    p.drawString(100, 670, f"Flight: {booking.flight.flight_number} | Seat: {booking.seat_number}")
    p.drawString(100, 650, f"From: {booking.flight.source}")
    p.drawString(100, 630, f"To: {booking.flight.destination}")
    p.drawString(100, 610, f"Fare: ₹{booking.total_amount} ({booking.payment_method})")
    p.drawString(100, 590, f"Status: {booking.status.upper()}")
    
    p.setFont("Helvetica-Oblique", 10)
    p.drawString(100, 550, "Thank you for flying with AeroNova Airways!")
    
    p.showPage()
    p.save()
    
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name=f"ticket_{booking_id}.pdf", mimetype='application/pdf')

if __name__ == '__main__':
    app.run(debug=True)
